package com.wordpress.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class CalcualtorTest 
{

	@Test
	public void testAddMethod_WithPositiveData()
	{
		Calculator c= new Calculator();
		int result = c.add(10, 20);
		Assert.assertEquals(result, 30);
	}
	
	@Test
	public void testAddMethod_WithNegativeData()
	{
		Calculator c= new Calculator();
		int result = c.add(-10, -20);
		Assert.assertEquals(result, -30);
	}
	
	@Test
	public void testAddMethod_WithMixedData()
	{
		Calculator c= new Calculator();
		int result = c.add(10, -20);
		Assert.assertEquals(result, -10);
	}
}
