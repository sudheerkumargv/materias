package com.wordpress.tests;

public class Calculator
{
		
	public int add(int a,int b)
	{
		int c = a+b;
		return c;
	}
	
	
	public int subtract(int a,int b)
	{
		return 0;
	}
}
