package com.wordpress.constants;

public interface Constants 
{
	String BROWSER_CHROME="chrome";
	String BROWSER_FIREFOX="firefox";
	
	String PROPERTY_WEBDRIVER_CHROME="webdriver.chrome.driver";
	String PROPERTY_WEBDRIVER_GECKO="webdriver.gecko.driver";
}
