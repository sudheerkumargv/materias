package com.twitter.tests;

import static io.restassured.RestAssured.*;
import org.testng.annotations.Test;
import io.restassured.path.json.JsonPath;

public class TwitterDeleteTweetsTests extends BaseTest
{
	
	@Test
	public void testDeleteTweet()
	{
		//To get first tweet it
		baseURI=twitter_baseURI;
		String response = given().auth().oauth(consumer_key, consumer_secret, access_token, token_secret).
		when().get("statuses/home_timeline.json").
		then().assertThat().statusCode(200).
		extract().response().asString();
		JsonPath jPath = new JsonPath(response);
		long tweetId = jPath.get("[0].id");
		
		//to delete tweet
		String deleteResponse = given().auth().oauth(consumer_key, consumer_secret, access_token, token_secret).param("status", "hello").
		when().post("statuses/destroy/"+tweetId+".json").
		then().assertThat().statusCode(200).
		extract().response().asString();
	
		System.out.println(deleteResponse);
	}
}
