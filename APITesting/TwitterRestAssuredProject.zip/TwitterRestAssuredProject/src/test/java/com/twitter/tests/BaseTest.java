package com.twitter.tests;



import com.twitter.utils.PropertiesUtil;

public class BaseTest 
{

	PropertiesUtil propUtil = new PropertiesUtil("./src/test/resources/config.properties");
	String consumer_key=propUtil.getProperyValue("consumer_key");  
	String consumer_secret=propUtil.getProperyValue("consumer_secret");  
	String access_token=propUtil.getProperyValue("access_token");  
	String token_secret=propUtil.getProperyValue("token_secret"); 
	String twitter_baseURI=propUtil.getProperyValue("twitter_base_uri"); 
	

	
}
