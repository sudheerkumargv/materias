package com.twitter.tests;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;

import com.twitter.constants.Constants;
import com.twitter.utils.ExcelUtil;



public class TwitterUpdateTests  extends BaseTest implements Constants
{
	
	//@Test
	public void testCreatTweet()
	{
		ExcelUtil eUtil = new ExcelUtil("./src/test/resources/status.xls",1);
		int numberOfRows = eUtil.getNumberOfRows();
		System.out.println(numberOfRows);
		for(int i = 1;i<=2;i++)
		{
			String status = eUtil.getCellValue(i, 0);
			String tweet = status+System.currentTimeMillis(); 
			baseURI=twitter_baseURI;
			String response = given().auth().oauth(consumer_key, consumer_secret, access_token, token_secret).param("status", tweet).
			when().post(resource_create_tweet).
			then().assertThat().statusCode(200).body("text", is(tweet)).
			extract().response().asString();
			System.out.println(response);
		}
	}
	
	
	
	@Test
	public void test()
	{
		String str = "= '?'bcdedfab= '?'defabcdef";
		
		
		//System.out.println(str.replace("a", "z"));
		System.out.println(str.replace("= '?'", "z"));
		
	}
}
