package com.twitter.tests;

import static io.restassured.RestAssured.*;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.twitter.constants.Constants;

import io.restassured.path.json.JsonPath;

public class TwitterGetTests extends BaseTest implements Constants
{

	@Test
	public void testGetAllTweets()
	{
		baseURI=twitter_baseURI;
		String response = given().auth().oauth(consumer_key, consumer_secret, access_token, token_secret).
		when().get(resource_get_tweets).
		then().assertThat().statusCode(200).
		extract().response().asString();
	
		JsonPath jPath = new JsonPath(response);
		Assert.assertTrue(!jPath.get("[0].text").equals(""));
		Assert.assertTrue(!jPath.get("[1].text").equals(""));
		System.out.println(response);
	}
	
	@Test
	public void testGetLatestSingleTweet()
	{
		baseURI=twitter_baseURI;
		String response = given().auth().oauth(consumer_key, consumer_secret, access_token, token_secret).param("count", "1").
		when().get("statuses/home_timeline.json").
		then().assertThat().statusCode(200).
		extract().response().asString();
		System.out.println(response);
		
		JsonPath jPath = new JsonPath(response);
		Assert.assertTrue(!jPath.get("[0].text").equals(""));
		Object object = jPath.get("[1].text");
		Assert.assertNull(object,"Null is expected, when trying to retrieve second object");

	}
	
	
	@Test
	public void testGetLatestTwoTweets()
	{
		baseURI=twitter_baseURI;
		String response = given().auth().oauth(consumer_key, consumer_secret, access_token, token_secret).param("count", "2").
		when().get("statuses/home_timeline.json").
		then().assertThat().statusCode(200).
		extract().response().asString();
		System.out.println(response);
		
		JsonPath jPath = new JsonPath(response);
		Assert.assertTrue(!jPath.get("[0].text").equals(""));
		Assert.assertTrue(!jPath.get("[1].text").equals(""));
		Object object = jPath.get("[2].text");
		Assert.assertNull(object,"Null is expected, when trying to retrieve second object");

	}
}
