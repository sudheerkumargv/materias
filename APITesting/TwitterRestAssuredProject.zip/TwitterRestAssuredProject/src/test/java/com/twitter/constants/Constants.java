package com.twitter.constants;

public interface Constants {

	String  resource_create_tweet="statuses/update.json";
	String  resource_get_tweets="statuses/home_timeline.json";
	
}
