package com.twitter.utils;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ExcelUtil 
{
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	
	public ExcelUtil(String filePath,int sheetIndex)
	{
		FileInputStream fis;
		try {
			fis = new FileInputStream(filePath);
			workbook = new HSSFWorkbook(fis);
			sheet = workbook.getSheetAt(sheetIndex);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public String getCellValue(int rowNo,int colNo)
	{
		HSSFRow row = sheet.getRow(rowNo);
		HSSFCell cell = row.getCell(colNo);
		String value = cell.toString();
		return value;
		
	}
	
	public int getNumberOfRows()
	{
		return sheet.getLastRowNum();
	}
}

