package com.twitter.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertiesUtil
{
		
	Properties prop;
	
	public PropertiesUtil(String filePath)
	{
		FileInputStream fis;
		try {
		prop = new Properties();
		fis = new FileInputStream(filePath);
		prop.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public String getProperyValue(String key)
	{
		String value = prop.getProperty(key);
		return value.trim();
	}
}
